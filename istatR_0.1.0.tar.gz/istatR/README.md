# istatR

R Interface to the Italian National Institute of Statistics (ISTAT) API

## Overview

`istatR` provides an R interface to the [ISTAT SDMX RESTful API](https://esploradati.istat.it/SDMXWS/rest), allowing users to:

- Discover all available ISTAT datasets
- Search for datasets by keyword
- Explore dataset structure and dimensions
- Retrieve statistical data with flexible filtering

This package is inspired by the Python [istatapi](https://github.com/Attol8/istatapi) package by Jacopo Attolini.

## Installation

```r
# Install from source
# devtools::install_github("your-username/istatR")

# Or install locally
devtools::install_local("path/to/istatR")
```

## Usage

### 1. Explore Available Datasets

```r
library(istatR)

# List all available datasets
datasets <- all_available()
head(datasets)
#> # A tibble: 6 × 4
#>   df_id   version df_description                                df_structure_id
#>   <chr>   <chr>   <chr>                                         <chr>
#> 1 101_1015 1.0    Population by marital status                  DCIS_POPRES1
#> 2 115_333  1.0    Consumer price index                          DCSP_IPCA
#> ...

# Search for specific datasets
import_datasets <- search_dataset("import")
population_datasets <- search_dataset("population")
```

### 2. Create a Dataset Object

```r
# Create dataset by ID
ds <- istat_dataset("139_176")
print(ds)
#> ISTAT Dataset
#> -------------
#> ID:           139_176
#> Version:      1.0
#> Description:  Foreign trade - imports and exports
#> Structure:    DCSC_COMMEST_EPORT
#>
#> Dimensions (7):
#>   - FREQ: (all)
#>   - MERCE_ATECO_2007: (all)
#>   - PAESE_PARTNER: (all)
#>   ...
```

### 3. Explore Dataset Structure

```r
# View dimension information
dimensions_info(ds)
#> # A tibble: 7 × 4
#>   dimension_id      position codelist_id              description
#>   <chr>                <int> <chr>                    <chr>
#> 1 FREQ                     1 CL_FREQ                  Frequency
#> 2 MERCE_ATECO_2007         2 CL_MERCE_ATECO2007       Product (ATECO 2007)
#> ...

# Get available values for a specific dimension
get_dimension_values(ds, "TIPO_DATO")
#> # A tibble: 4 × 2
#>   id    name
#>   <chr> <chr>
#> 1 ISAV  Imports - value
#> 2 ESAV  Exports - value
#> 3 ISAQ  Imports - quantity
#> 4 ESAQ  Exports - quantity

# Get all available values
available <- get_available_values(ds)
available$FREQ
```

### 4. Set Filters and Retrieve Data

```r
# Set filters
ds <- set_filters(ds,
  FREQ = "M",
  TIPO_DATO = c("ISAV", "ESAV"),  # Multiple values
  PAESE_PARTNER = "WORLD"
)

# Retrieve data
data <- get_data(ds)

# Or use time period filters
data <- get_data(ds,
  start_period = "2020-01-01",
  end_period = "2023-12-31"
)

# Get only the last 12 observations
data <- get_data(ds, last_n_observations = 12)
```

### 5. Quick Retrieval (One-liner)

```r
# Combine all steps in one function call
data <- istat_get(
  "139_176",
  FREQ = "M",
  TIPO_DATO = "ISAV",
  PAESE_PARTNER = "WORLD",
  start_period = "2022-01-01"
)
```

## Main Functions

| Function | Description |
|----------|-------------|
| `all_available()` | List all available ISTAT datasets |
| `search_dataset(keyword)` | Search datasets by keyword in description |
| `istat_dataset(id)` | Create a dataset object for exploration |
| `dimensions_info(ds)` | Get information about dataset dimensions |
| `get_dimension_values(ds, dim)` | Get available values for a dimension |
| `get_available_values(ds)` | Get all available values for all dimensions |
| `set_filters(ds, ...)` | Set dimension filters |
| `reset_filters(ds)` | Reset all filters to default |
| `get_data(ds)` | Retrieve data with current filters |
| `istat_get(id, ...)` | Quick retrieval combining all steps |
| `istat_timeout(seconds)` | Get or set the API timeout |

## API Timeout

**Note:** The ISTAT API can be slow to respond, especially when listing all datasets or retrieving large amounts of data. The default timeout is set to **300 seconds (5 minutes)** to accommodate this.

If you encounter timeout errors, you can increase the timeout:

```r
# Check current timeout
istat_timeout()
#> [1] 300

# Increase timeout to 10 minutes
istat_timeout(600)

# Or even longer for very large queries
istat_timeout(900)  # 15 minutes
```

## API Reference

This package uses the ISTAT SDMX REST API:
- Base URL: `https://esploradati.istat.it/SDMXWS/rest`
- Agency ID: `IT1`

See the [API documentation](https://developers.italia.it/it/api/istat-sdmx-rest) for more details.

## Example: Plotting Italian Agricultural Data

Here's a complete example that retrieves Italian crop production data and creates a visualization using base R graphics:

```r
library(istatR)

# Get Italian wine grape production over time
ds <- istat_dataset("101_1015")  # Crops dataset
ds <- set_filters(ds,
  FREQ = "A",           # Annual data
  REF_AREA = "IT",      # Italy
  DATA_TYPE = "TP_Q",   # Total production quantity
  TYPE_OF_CROP = "WINE" # Wine grapes
)

wine_data <- get_data(ds)

# Aggregate by year (sum across all wine grape types)
yearly_production <- aggregate(
  OBS_VALUE ~ TIME_PERIOD,
  data = wine_data,
  FUN = sum,
  na.rm = TRUE
)

# Create the plot
par(mar = c(5, 5, 4, 2))
plot(
  yearly_production$TIME_PERIOD,
  yearly_production$OBS_VALUE / 1e6,
  type = "b",
  pch = 19,
  col = "#8B0000",
  lwd = 2,
  xlab = "Year",
  ylab = "Production (Million Quintals)",
  main = "Italian Wine Grape Production",
  sub = "Source: ISTAT",
  las = 1,
  cex.main = 1.2
)
grid(col = "gray90")

# Add trend line
abline(
  lm(OBS_VALUE / 1e6 ~ as.numeric(TIME_PERIOD), data = yearly_production),
  col = "#8B0000",
  lty = 2,
  lwd = 1.5
)
```

This produces a time series plot showing the evolution of Italian wine grape production over time.

## License
Apache License 2.0

## Acknowledgments

- Inspired by [istatapi](https://github.com/Attol8/istatapi) Python package by Jacopo Attolini
- Data provided by [ISTAT](https://www.istat.it/) - Italian National Institute of Statistics
